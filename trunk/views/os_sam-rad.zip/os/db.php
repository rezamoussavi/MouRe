<?php
	$UN="RocketViews";
	$Pass="maxmirkia";
	$DataBase="VocketViews_biz";
	$ServerAddress="localhost";
?>
