<?php
	$UN="samrad_db";
	$Pass="maxmirkia";
	$DataBase="samrad_db";
	$ServerAddress="localhost";
?>
