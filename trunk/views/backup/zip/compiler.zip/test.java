
public class test {

	/**
	 * @param args
	 */
	public static void _main(String[] args) {
		// TODO Auto-generated method stub
		String s="reza moussavi is reza here";
		System.out.println(s.indexOf("e", 270));
	}

}
