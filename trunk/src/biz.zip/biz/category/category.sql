{\rtf1\ansi\ansicpg1252\cocoartf1038\cocoasubrtf320
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\ql\qnatural\pardirnatural

\f0\fs24 \cf0 CREATE TABLE `category_cat` (\
  `catUID` int(11) NOT NULL AUTO_INCREMENT,\
  `Lable` varchar(128) NOT NULL,\
  `owner_type` varchar(128) NOT NULL,\
  `owner_name` varchar(128) NOT NULL,\
  `owner_UID` int(11) NOT NULL,\
  `typeUID` int(11) NOT NULL,\
  PRIMARY KEY (`catUID`),\
  KEY `typeUID` (`typeUID`)\
)\
\
CREATE TABLE `category_content` (\
  `catUID` int(11) NOT NULL,\
  `bizname` varchar(128) NOT NULL,\
  `bizUID` int(11) NOT NULL,\
  `extra` varchar(128) NOT NULL,\
  KEY `catUID` (`catUID`)\
) \
\
CREATE TABLE `category_type` (\
  `typeUID` int(11) NOT NULL AUTO_INCREMENT,\
  `name` varchar(128) NOT NULL,\
  PRIMARY KEY (`typeUID`)\
)}